
print "Introduce el primer número: "
num1 = gets.chomp.to_i

print "Introduce el segundo número: "
num2 = gets.chomp.to_i

if num1 + num2 > 30
  puts "La suma es mayor a 30, se iniciará el contador"
   while sum < 50
    sum += 5
    puts "El contador es: #{sum}"
  end

else num1 + num2 < 30
  puts "La suma es menor a 30, no se iniciara el contador"
  sum = 0
end
 