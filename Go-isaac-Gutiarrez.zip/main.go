package main

import (
	"fmt"
)

func main() {
    var horasTrabajadas, costoHora float64
    fmt.Print("Ingrese las horas totales trabajadas: ")
    fmt.Scan(&horasTrabajadas)
    fmt.Print("Ingrese el costo por hora trabajada: ")
    fmt.Scan(&costoHora)
    sueldo := horasTrabajadas * costoHora
    fmt.Printf("El sueldo total del empleado es: %.2f", sueldo)
}
