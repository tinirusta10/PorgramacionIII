use std::io;
fn main() {
    println!("Ingrese el primer número: ");

    let mut num1 = String::new(); 

    io::stdin().read_line(&mut num1).expect("Error al leer la entrada"); 

    let num1: i32 = num1.trim().parse().expect("Por favor ingrese un número válido"); 

    println!("Ingrese el segundo número: ");

    let mut num2 = String::new();

    io::stdin().read_line(&mut num2).expect("Error al leer la entrada"); 

    let num2: i32 = num2.trim().parse().expect("Por favor ingrese un número válido"); 

    let resultado = num1 + num2;

    println!("La suma de {} y {} es: {}", num1, num2, resultado);
}