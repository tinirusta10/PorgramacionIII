const http = require('http');

const url = process.argv[2];

http.get(url, (res) => {
  res.on('data', (chunk) => {
    console.log(`data: ${chunk.toString()}`);
  });
  res.on('error', (err) => {
    console.error(`error: ${err.message}`);
  });
  res.on('end', () => {
    console.log('end');
  });
}).on('error', (err) => {
  console.error(`Error al hacer la petición: ${err.message}`);
});