function calcularAreaTriangulo(base: number, altura: number): number {
  const area = (base * altura) / 2;
  return area;
}

console.log(calcularAreaTriangulo(10, 3));
