let productos = ["Manzana":30,"Mesa":7000,"Pera":40]

for(producto,precio) in productos{
  print("\(producto) cuesta \(precio) pesos")
}

