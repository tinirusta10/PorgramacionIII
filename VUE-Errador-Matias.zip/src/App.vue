
<template>
  <div>
    <h1>{{ contador }}</h1>
    <button @click="incrementarCont">Incrementar</button>
    <button @click="decrementarCont">Decrementar</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      contador: 0
    };
  },
  methods: {
    incrementarCont() {
      this.contador++;
    },
    decrementarCont() {
      if (this.contador > 0) {
        this.contador--;
      }
    }
  }
};
</script>
